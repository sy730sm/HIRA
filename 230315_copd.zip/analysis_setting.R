###########################################################################
########################  Local Configuration #############################
###########################################################################

### Set Configuration parameters
setwd('./')  # working directory

project<- '' #one of 26/27 setting 폴더 이름 참조




dbms=''
user=''
password=''
dbServer=''
pathToDriver=''


schema_cdm<-''     # CDM data schema (OMOP Standardized Clinical Tables) ex)cdm
schema_vocab<-''  # CDM Vocabulary schema (OMOP Standardized Vocabularies) ex)cdm
schema_analysis<-'' # CDM schema for analysis table (CREATE, USAGE needed) ex)public


oracleTempSchema <- NULL
maxCores<-1
databaseId <- 'HIRA'
databaseName <- 'HIRAdb'
databaseDescription <- 'HIRAdb'


### Connect DB
connectionDetails <- createConnectionDetails(dbms=dbms, 
                                             user=user, 
                                             password=password,
                                             server=dbServer, 
                                             pathToDriver = pathToDriver)
con <- connect(connectionDetails)

#create incidence_summary table in "schema_analysis"
ddl <- SqlRender::render(CohortIncidence::getResultsDdl(), schemaName = schema_analysis)
con <- DatabaseConnector::connect(connectionDetails)
DatabaseConnector::executeSql(con,ddl)



