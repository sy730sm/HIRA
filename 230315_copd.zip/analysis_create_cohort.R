###########################################################################
######################### Analysis Start ##################################
###########################################################################


setting <- paste0("setting_estimation_",project)

setting_dir<-paste0(getwd(),"/",setting,"/")  # directory where setting files exist
output_dir<-gsub("setting","result",setting_dir) # directory to save result
if (!file.exists(output_dir)){
  dir.create(output_dir)
}

appDir<-paste0(getwd(),"/","shiny/EvidenceExplorer") #directory where shiny exist


cohortTable <- gsub("setting","SNUH",setting) # Name of the  table where the study-specific cohorts will be instantiated



resultsZipFile <- file.path(output_dir, "export", paste0("Results_", databaseId,gsub("setting",'',setting) ,".zip"))
dataFolder <- file.path(output_dir, "shinyData")

# import files


for (file in list.files(setting_dir)) {
  nm_file<-split_str(file,"\\.",1,1)
  print(nm_file)
  if (grepl("csv",file)) {
    assign(nm_file,fread(file=paste0(setting_dir,file)))
  }else if(grepl("sql",file)){
    assign(nm_file,readSql(paste0(setting_dir,file)))
  }else if(grepl("json",file)){
    assign(nm_file,CohortMethod::loadCmAnalysisList(paste0(setting_dir,file)))
  }
  
  
}



###################### Create Cohort #######################

# Create study cohort table structure:
ParallelLogger::logInfo("Creating exposure and outcome cohorts")
sql <- translate(render(CreateCohortTable, cohort_database_schema = schema_analysis,
                        cohort_table = cohortTable),targetDialect = my_dbms)

DatabaseConnector::executeSql(con, sql, progressBar = FALSE, reportOverallTime = FALSE)


# Instantiate cohorts:

for (i in 1:nrow(CohortsToCreate)) {
  writeLines(paste("Creating cohort:", CohortsToCreate$name[i]))
  sql <- translate(render(get(CohortsToCreate$name[i]), 
                          cdm_database_schema = schema_cdm,
                          vocabulary_database_schema = schema_vocab,
                          target_database_schema = schema_analysis,
                          target_cohort_table = cohortTable,
                          target_cohort_id = CohortsToCreate$cohortId[i]),targetDialect = my_dbms)
  DatabaseConnector::disconnect(con)
  con <- connect(connectionDetails)
  DatabaseConnector::executeSql(con, sql)
  
}



ParallelLogger::logInfo("Creating negative control outcome cohorts")
# Currently assuming all negative controls are outcome controls

sql <- translate(render(NegativeControlOutcomes, 
                        cdm_database_schema = schema_cdm,
                        target_database_schema = schema_analysis,
                        target_cohort_table = cohortTable,
                        outcome_ids = unique(NegativeControls$outcomeId)),targetDialect = my_dbms)

DatabaseConnector::executeSql(con, sql)

con <- connect(connectionDetails)

