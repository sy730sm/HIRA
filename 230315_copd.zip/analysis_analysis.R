# Fetch cohort counts:
sql_c <- "SELECT cohort_definition_id, COUNT(*) AS count FROM @cohort_database_schema.@cohort_table GROUP BY cohort_definition_id"

sql <- translate(render(sql_c, cohort_database_schema = schema_analysis,
                        cohort_table = cohortTable),targetDialect = my_dbms)


counts <- DatabaseConnector::querySql(con, sql)
names(counts) <- SqlRender::snakeCaseToCamelCase(names(counts))
counts <- merge(counts, data.frame(cohortDefinitionId = CohortsToCreate$cohortId,
                                   cohortName  = CohortsToCreate$name))
write.csv(counts, file.path(output_dir, "CohortCounts.csv"),row.names = F)


covariateSettings <- createCovariateSettings(useDemographicsGender = TRUE,
                                             useDemographicsAge = TRUE,
                                             useDemographicsAgeGroup = TRUE,
                                             useConditionOccurrenceLongTerm = TRUE,
                                             useDrugGroupEraLongTerm = TRUE)


covariateData_target <- getDbCovariateData(connectionDetails = connectionDetails,
                                           cdmDatabaseSchema = schema_cdm,
                                           cohortDatabaseSchema = schema_analysis,
                                           cohortTable = cohortTable,
                                           cohortId = CohortsToCreate$cohortId[1],
                                           covariateSettings = covariateSettings,
                                           aggregated = TRUE)
covariateData_comparator <- getDbCovariateData(connectionDetails = connectionDetails,
                                               cdmDatabaseSchema = schema_cdm,
                                               cohortDatabaseSchema = schema_analysis,
                                               cohortTable = cohortTable,
                                               cohortId = CohortsToCreate$cohortId[2],
                                               covariateSettings = covariateSettings,
                                               aggregated = TRUE)
summary(covariateData_target)

std <- computeStandardizedDifference(covariateData_target, covariateData_comparator)
write.csv(std,file.path(output_dir, "standard_difference.csv"),row.names = F)
test_covariate<- bind_rows(covariateData_target$covariateRef %>% as.data.frame(),covariateData_comparator$covariateRef %>% as.data.frame()) %>% unique()
write.csv(test_covariate,file.path(output_dir, "baselinecharacteristics_header.csv"),row.names = F)

table1specification<-tibble(label = c("Age","Age group","Gender: female","Gender: male","Medical history","Medication use"),
                            analysisId = c(2,3,1,1,102,410),
                            covariateIds = c(NA,NA,"8507001","8532001",
                                             paste0(test_covariate %>% filter(analysisId==102) %>% select(covariateId) %>% unlist() %>% unname(),collapse=","),
                                             paste0(test_covariate %>% filter(analysisId==410) %>% select(covariateId) %>% unlist() %>% unname(),collapse=",")))



result <- createTable1(covariateData_target, covariateData_comparator,
                       specifications = table1specification,
                       output = "one column",
                       showCounts = TRUE,
                       showPercent = TRUE,
                       percentDigits = 1,
                       valueDigits = 1,
                       stdDiffDigits = 2)
write.csv(result,file.path(output_dir, "baselinecharacteristics.csv"),row.names = F)



t1 <- CohortIncidence::createCohortRef(id=CohortsToCreate$cohortId[1], name=CohortsToCreate$name[1])
c1 <-CohortIncidence::createCohortRef(id=CohortsToCreate$cohortId[2], name=CohortsToCreate$name[2])

o1 <- CohortIncidence::createOutcomeDef(id=CohortsToCreate$cohortId[3],name="Outcome 1 ",
                                        cohortId =CohortsToCreate$cohortId[3])
o2 <- CohortIncidence::createOutcomeDef(id=CohortsToCreate$cohortId[4],name="Outcome 2 ",
                                        cohortId =CohortsToCreate$cohortId[4])
tar1 <- CohortIncidence::createTimeAtRiskDef(id=1,
                                             startWith="start",
                                             endWith="end")
# Note: c() is used when dealing with an array of numbers,
# later we use list() when dealing with an array of objects
analysis1 <- CohortIncidence::createIncidenceAnalysis(targets = c(t1$id,c1$id),
                                                      outcomes = c(o1$id,o2$id),
                                                      tars = c(tar1$id))
irDesign <- CohortIncidence::createIncidenceDesign(targetDefs = list(t1,c1),
                                                   outcomeDefs = list(o1,o2),
                                                   tars=list(tar1),
                                                   analysisList = list(analysis1))

buildOptions <- CohortIncidence::buildOptions(cohortTable = cohortTable,
                                              cdmDatabaseSchema = schema_cdm,
                                              sourceName = "mysource",
                                              refId = 1)


executeResults <- CohortIncidence::executeAnalysis(connectionDetails = connectionDetails,
                                                   incidenceDesign = irDesign,
                                                   buildOptions = buildOptions)

write.csv(executeResults,file.path(output_dir, "incidence.csv"),row.names = F)



###################### Run Analysis #######################



ParallelLogger::logInfo("Running CohortMethod analyses")
cmoutput_dir <- file.path(output_dir, "cmOutput")
if (!file.exists(cmoutput_dir)) {
  dir.create(cmoutput_dir)
}

tcosList <- createTcos(outputFolder = output_dir)
outcomesOfInterest <- getOutcomesOfInterest()
results <- CohortMethod::runCmAnalyses(connectionDetails = connectionDetails,
                                       cdmDatabaseSchema = schema_cdm,
                                       exposureDatabaseSchema = schema_analysis,
                                       exposureTable = cohortTable,
                                       outcomeDatabaseSchema = schema_analysis,
                                       outcomeTable = cohortTable,
                                       outputFolder = cmoutput_dir,
                                       oracleTempSchema = oracleTempSchema,
                                       cmAnalysisList = cmAnalysisList,
                                       targetComparatorOutcomesList = tcosList,
                                       getDbCohortMethodDataThreads = min(3, maxCores),
                                       createStudyPopThreads = min(3, maxCores),
                                       createPsThreads = max(1, round(maxCores/10)),
                                       psCvThreads = min(10, maxCores),
                                       trimMatchStratifyThreads = min(10, maxCores),
                                       fitOutcomeModelThreads = max(1, round(maxCores/4)),
                                       outcomeCvThreads = min(4, maxCores),
                                       refitPsForEveryOutcome = FALSE,
                                       outcomeIdsOfInterest = outcomesOfInterest
)

ParallelLogger::logInfo("Summarizing results")
analysisSummary <- CohortMethod::summarizeAnalyses(referenceTable = results, 
                                                   outputFolder = cmoutput_dir)
analysisSummary <- addCohortNames(analysisSummary, "targetId", "targetName")
analysisSummary <- addCohortNames(analysisSummary, "comparatorId", "comparatorName")
analysisSummary <- addCohortNames(analysisSummary, "outcomeId", "outcomeName")
analysisSummary <- addAnalysisDescription(analysisSummary, "analysisId", "analysisDescription")
write.csv(analysisSummary, file.path(output_dir, "analysisSummary.csv"), row.names = FALSE)
saveRDS(results,file.path(output_dir, "cmresult.rds"))


ParallelLogger::logInfo("Computing covariate balance") 
balanceFolder <- file.path(output_dir, "balance")
if (!file.exists(balanceFolder)) {
  dir.create(balanceFolder)
}
subset <- results[results$outcomeId %in% outcomesOfInterest,]
subset <- subset[subset$strataFile != '', ]
if (nrow(subset) > 0) {
  subset2 <- split(subset, seq(nrow(subset)))
  cluster <- ParallelLogger::makeCluster(min(3, maxCores))
  ParallelLogger::clusterApply(cluster, subset2, computeCovariateBalancef, cmOutputFolder = cmoutput_dir, balanceFolder = balanceFolder)
  ParallelLogger::stopCluster(cluster)
  
  
}

for (i in seq(1,nrow(subset))) {
  strataFile <- subset[i,]$strataFile
  cohortMethodDataFile  <- subset[i,]$cohortMethodDataFile
  tmp_cohort<-CohortMethod::loadCohortMethodData(file.path(cmoutput_dir, cohortMethodDataFile))$cohorts %>% as.data.frame()
  analysisname<- paste0("Analysis",subset[i,]$analysisId,"_",subset[i,]$outcomeId )
  tablename<- paste0(cohortTable,"_",analysisname)
  tmp<-readRDS(file.path(cmoutput_dir, strataFile))
  if (nrow(tmp)!=0) {
    lst_person<- tmp_cohort %>% filter(rowId %in% tmp$rowId) %>% select(personId) %>% unlist() %>% unname()
    lst_person<-as.numeric(lst_person)
    code_vec<-function(x){ return(noquote(paste0('(', paste0( x, collapse = "," ), ')'))) }
    sql<- "DROP TABLE IF EXISTS @cohort_database_schema.@tablename;CREATE TABLE @cohort_database_schema.@tablename as (select * from @cohort_database_schema.@cohortTable where subject_id in @patlist);"
    sql <- translate(render(sql, cohort_database_schema = schema_analysis,tablename=tablename,
                            cohortTable = cohortTable,patlist=code_vec(lst_person)),targetDialect = my_dbms)
    
    DatabaseConnector::executeSql(con, sql, progressBar = FALSE, reportOverallTime = FALSE)
    
    
    
    covariateData_target <- getDbCovariateData(connectionDetails = connectionDetails,
                                               cdmDatabaseSchema = schema_cdm,
                                               cohortDatabaseSchema = schema_analysis,
                                               cohortTable = tablename,
                                               cohortId = CohortsToCreate$cohortId[1],
                                               covariateSettings = covariateSettings,
                                               aggregated = TRUE)
    covariateData_comparator <- getDbCovariateData(connectionDetails = connectionDetails,
                                                   cdmDatabaseSchema = schema_cdm,
                                                   cohortDatabaseSchema = schema_analysis,
                                                   cohortTable = tablename,
                                                   cohortId = CohortsToCreate$cohortId[2],
                                                   covariateSettings = covariateSettings,
                                                   aggregated = TRUE)
    if (nrow(covariateData_target$covariates %>% as.data.frame())!=0 &&
        nrow(covariateData_comparator$covariates%>% as.data.frame())!=0) {
      std <- computeStandardizedDifference(covariateData_target, covariateData_comparator)
      write.csv(std,file.path(output_dir, paste0("standard_difference_",analysisname,".csv")),row.names = F)
      test_covariate<- bind_rows(covariateData_target$covariateRef %>% as.data.frame(),covariateData_comparator$covariateRef %>% as.data.frame()) %>% unique()
      
      table1specification<-tibble(label = c("Age","Age group","Gender: female","Gender: male","Medical history","Medication use"),
                                  analysisId = c(2,3,1,1,102,410),
                                  covariateIds = c(NA,NA,"8507001","8532001",
                                                   paste0(test_covariate %>% filter(analysisId==102) %>% select(covariateId) %>% unlist() %>% unname(),collapse=","),
                                                   paste0(test_covariate %>% filter(analysisId==410) %>% select(covariateId) %>% unlist() %>% unname(),collapse=",")))
      
      
      
      result <- createTable1(covariateData_target, covariateData_comparator,
                             specifications = table1specification,
                             output = "one column",
                             showCounts = TRUE,
                             showPercent = TRUE,
                             percentDigits = 1,
                             valueDigits = 1,
                             stdDiffDigits = 2)
      write.csv(result,file.path(output_dir, paste0("baselinecharacteristics_",analysisname,".csv")),row.names = F)
    }
    
    
    
  }
  
  
  
}








###################### Export Analysis Result by Shiny #######################

exportResults(outputFolder = output_dir,
              databaseId = databaseId,
              databaseName = databaseName,
              databaseDescription = databaseDescription,
              minCellCount = 5,
              maxCores = maxCores)

exportFolder <- file.path(output_dir, "export")


# Add all to zip file -------------------------------------------------------------------------------
ParallelLogger::logInfo("Adding results to zip file")
zipName <- resultsZipFile

for (file in list.files(output_dir, pattern = ".*\\.csv$")) {
  file.copy(file.path(output_dir, file),exportFolder)
}



files <- c(list.files(exportFolder, pattern = ".*\\.csv$"))
oldWd <- setwd(exportFolder)
on.exit(setwd(oldWd))
DatabaseConnector::createZipFile(zipFile = zipName, files = files)
ParallelLogger::logInfo("Results are ready for sharing at:", zipName)
}

